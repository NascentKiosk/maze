import React, { Component } from 'react';
import Game from './Game';

class App extends Component {
  render() {
    return (
      <div className="main-app-container">
        <Game />
      </div>
    );
  }
}

export default App